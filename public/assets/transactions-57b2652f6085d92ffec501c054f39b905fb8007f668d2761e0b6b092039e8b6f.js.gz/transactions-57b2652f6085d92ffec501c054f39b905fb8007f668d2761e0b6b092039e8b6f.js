// app/assets/javascripts/transactions.js

$(document).on('turbolinks:load', function() {
    $('#transaction_account_id').on('change', function() {
      // Update funds based on the selected account
      // Implement your logic here
    });
  
    $('#transaction_expense_id').on('change', function() {
      // Update funds based on the selected expense
      // Implement your logic here
    });
  });
  
